 function calculateBatterySizing() {
    // Inputs
    const E = parseFloat(document.getElementById("dailyEnergy").value); // Daily Energy Consumption (Wh/day)
    const t = parseFloat(document.getElementById("Autonomy").value); // Autonomy (days)
    const V = parseFloat(document.getElementById("systemVoltage").value); // System Voltage (V)
    const top = parseFloat(document.getElementById("weightedOpTime").value); // Weighted Average Operating Time (hours/day)
    const to = parseFloat(document.getElementById("dischargeAutonomy").value); // Autonomy for Discharge Rate Calculation (days)
    const DODa = parseFloat(document.getElementById("dischargeDOD").value); // DOD for Discharge Rate Calculation
    const allowableDOD = parseFloat(document.getElementById("allowableDOD").value); // Allowable Depth of Discharge
    const CTr = parseFloat(document.getElementById("deratingFactor").value); // Temperature and Discharge Rate Derating Factor
    const Bout = parseFloat(document.getElementById("requiredBatteryOutput").value); // Required Battery Output (Ah)

    // Calculations
    const batteryOutput = (E * t) / V; // Battery Size (Ah)
    const dischargeRate = (top * to) / DODa; // Average Discharge Rate (hours)
    const ratedBatteryCapacity = Bout / (allowableDOD * CTr); // Battery Bank Rated Capacity (Ah)

    // Results
    const result = `
      Required Battery Output: ${batteryOutput.toFixed(2)} Ah<br>
      Average Discharge Rate: ${dischargeRate.toFixed(2)} hours<br>
      Battery Bank Rated Capacity: ${ratedBatteryCapacity.toFixed(2)} Ah
    `;
    document.getElementById("batteryResult").innerHTML = result;
  }
function calculatePVSystem() {
  // Inputs
  const Pmp = parseFloat(document.getElementById('Pmp').value);
  const Pg = parseFloat(document.getElementById('Pg').value) / 100;
  const nm = parseFloat(document.getElementById('nm').value);
  const PSH = parseFloat(document.getElementById('PSH').value);
  const Avetemp = parseFloat(document.getElementById('Avetemp').value);
  const STC = parseFloat(document.getElementById('STC').value);
  const Ctemp = parseFloat(document.getElementById('Ctemp').value) / 100; // Internally negative
  const wiringLoss = parseFloat(document.getElementById('wiringLoss').value) / 100;
  const InvEff = parseFloat(document.getElementById('InvEff').value) / 100;
  const InvMPPT = parseFloat(document.getElementById('InvMPPT').value) / 100;
  const monthlyBill = parseFloat(document.getElementById('monthlyBill').value);
  const panelCost = parseFloat(document.getElementById('panelCost').value);
  const inverterCost = parseFloat(document.getElementById('inverterCost').value);
  const laborRate = parseFloat(document.getElementById('laborRate').value);
  const annualCleaning = parseFloat(document.getElementById('annualCleaning').value);
  const region = document.getElementById('region').value;

  // Validate inputs
  if (isNaN(monthlyBill) || monthlyBill <= 0) {
    alert("Please enter a valid monthly bill amount.");
    return;
  }
  if (isNaN(nm) || nm < 1 || isNaN(PSH) || PSH <= 0) {
    alert("Please enter valid values for required fields.");
    return;
  }

  // Tariff rates based on region
  let tariffBlocks;
  if (region === "peninsular") {
    tariffBlocks = [
      { limit: 200, rate: 0.218 },
      { limit: 100, rate: 0.334 },
      { limit: 300, rate: 0.516 },
      { limit: 300, rate: 0.546 },
      { limit: Infinity, rate: 0.571 },
    ];
  } else if (region === "sabah") {
    tariffBlocks = [
      { limit: 100, rate: 0.175 },
      { limit: 200, rate: 0.185 },
      { limit: 300, rate: 0.33 },
      { limit: 500, rate: 0.445 },
      { limit: 1000, rate: 0.45 },
      { limit: Infinity, rate: 0.47 },
    ];
  }

  // Calculate import charge breakdown
  let remainingBill = monthlyBill;
  let totalUsage = 0;
  let breakdown = []; // Store (kWh used, rate, cost)

  for (let block of tariffBlocks) {
    const blockCost = block.limit * block.rate;

    if (remainingBill <= blockCost) {
      const blockUsage = remainingBill / block.rate;
      breakdown.push({ usage: blockUsage, rate: block.rate, cost: remainingBill });
      totalUsage += blockUsage;
      break;
    } else {
      breakdown.push({ usage: block.limit, rate: block.rate, cost: blockCost });
      totalUsage += block.limit;
      remainingBill -= blockCost;
    }
  }

  const lastRate = breakdown[breakdown.length - 1].rate;

  // PV Calculations
  const Parr_g = Pmp * Pg * nm;
  const PVcon = Parr_g * ((Avetemp - STC) * -Ctemp); // Use negative coefficient internally
  const Parr_T = Parr_g + PVcon;
  const Parr_net = Parr_T * (1 - wiringLoss);
  const PoutAC = Parr_net * InvEff * InvMPPT;
  const Poutave = PoutAC * PSH;
  const MEP = (Poutave * 30) / 1000;

  // Savings and Costs
  const PV_saving = MEP * lastRate;
  const totalPanelCost = panelCost * nm;
  const maintenanceCost = annualCleaning ;
  const totalCost = totalPanelCost + inverterCost + laborRate + maintenanceCost;

  const billAfterPV = monthlyBill - PV_saving;
  const paybackPeriod = totalCost / (PV_saving * 12);

  // Output the results
  document.getElementById('result').innerHTML = `
    <h3>Monthly Bill Breakdown:</h3>
    <table border="1">
      <tr><th>kWh Usage</th><th>Rate (RM/kWh)</th><th>Cost (RM)</th></tr>
      ${breakdown.map(item => `<tr><td>${item.usage.toFixed(2)}</td><td>${item.rate.toFixed(3)}</td><td>${item.cost.toFixed(2)}</td></tr>`).join('')}
      <tr><th>Total Usage (kWh)</th><td colspan="2">${totalUsage.toFixed(2)}</td></tr>
      <tr><th>Actual Bill (RM)</th><td colspan="2">${monthlyBill.toFixed(2)}</td></tr>
      <tr><th>Bill Saved After PV Installation (RM)</th><td colspan="2">${PV_saving.toFixed(2)}</td></tr>
      <tr><th>Bill After PV Installation (RM)</th><td colspan="2">${billAfterPV.toFixed(2)}</td></tr>
    </table>

    <h3>PV System Calculation:</h3>
    <p>1. Parr_g (Minimum Guaranteed Power Output of the Array): ${Parr_g.toFixed(2)} W</p>
    <p>2. Parr_T (Temperature-Corrected Array Power Output): ${Parr_T.toFixed(2)} W</p>
    <p>3. Parr_net (Net Array Power Output after Wiring Losses): ${Parr_net.toFixed(2)} W</p>
    <p>4. PoutAC (Inverter Maximum AC Power Output): ${PoutAC.toFixed(2)} W</p>
    <p>5. Poutave (Average Daily Energy Production): ${Poutave.toFixed(2)} Wh/day</p>
    <p>6. MEP (Monthly Energy Production): ${MEP.toFixed(2)} kWh</p>
    <p>7. Total PV Panel Price: RM ${totalPanelCost.toFixed(2)}</p>
    <p>8. Total Inverter Price: RM ${inverterCost.toFixed(2)}</p>
    <p>9. Total Labor Price: RM ${laborRate.toFixed(2)}</p>
    <p>10. Total Maintenance Price: RM ${maintenanceCost.toFixed(2)}</p>
    <p>11. Total Cost: RM ${totalCost.toFixed(2)}</p>
    <p>12. Total Payback Period: ${paybackPeriod.toFixed(2)} years</p>
  `;
  
}

